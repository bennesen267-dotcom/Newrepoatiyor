package dev.hvhclient.setting;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;

/** Açılır menüde birden fazla seçenek seçilebilen ayar (ör. silah listesi). */
public class MultiSetting extends Setting {
    private final List<String> options;
    private final Set<String> optionSet;
    private final Function<String, String> labeler;
    private final Set<String> selected = new LinkedHashSet<>();
    private final Map<String, String> searchKeys = new HashMap<>();
    private String search = "";
    private boolean open;

    public MultiSetting(String name, List<String> options, List<String> defaults) {
        this(name, options, defaults, s -> s);
    }

    /** labeler: seçenek anahtarını menüde görünecek isme çevirir. */
    public MultiSetting(String name, List<String> options, List<String> defaults, Function<String, String> labeler) {
        super(name);
        this.options = options;
        this.optionSet = new HashSet<>(options);
        this.labeler = labeler;
        this.selected.addAll(defaults);
    }

    public List<String> getOptions() { return options; }
    public String label(String option) { return labeler.apply(option); }
    public boolean isSelected(String option) { return selected.contains(option); }
    public int selectedCount() { return selected.size(); }

    public void toggle(String option) {
        if (!selected.remove(option)) selected.add(option);
    }

    public String getSearch() { return search; }
    public void setSearch(String value) { search = value; }

    /** Arama metni boşsa true; değilse isimde veya id'de geçiyorsa true. */
    public boolean matches(String option) {
        if (search.isEmpty()) return true;
        String key = searchKeys.computeIfAbsent(option,
                o -> (labeler.apply(o) + " " + o).toLowerCase());
        return key.contains(search.toLowerCase());
    }

    public boolean isOpen() { return open; }
    public void toggleOpen() { open = !open; }

    @Override
    public JsonElement save() {
        JsonArray arr = new JsonArray();
        for (String s : selected) arr.add(new JsonPrimitive(s));
        return arr;
    }

    @Override
    public void load(JsonElement json) {
        if (!json.isJsonArray()) return;
        selected.clear();
        for (JsonElement e : json.getAsJsonArray()) {
            String s = e.getAsString();
            if (optionSet.contains(s)) selected.add(s);
        }
    }
}
