package dev.hvhclient.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

/** Yazı girilebilen ayar (ClickGUI'de tıklayıp yazılır). */
public class TextSetting extends Setting {
    private final int maxLen;
    private String value;

    public TextSetting(String name, String def, int maxLen) {
        super(name);
        this.maxLen = maxLen;
        this.value = def.length() > maxLen ? def.substring(0, maxLen) : def;
    }

    public String get() { return value; }
    public int getMaxLen() { return maxLen; }
    public void set(String v) { value = v.length() > maxLen ? v.substring(0, maxLen) : v; }

    @Override
    public JsonElement save() { return new JsonPrimitive(value); }

    @Override
    public void load(JsonElement json) {
        if (json.isJsonPrimitive() && json.getAsJsonPrimitive().isString()) set(json.getAsString());
    }
}
