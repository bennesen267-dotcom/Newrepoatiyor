package dev.hvhclient.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

/** Tuş seçilen ayar (ClickGUI'de tıklayıp tuşa basılır). -1 = atanmamış. */
public class KeySetting extends Setting {
    private int key = -1;

    public KeySetting(String name) {
        super(name);
    }

    public int get() { return key; }
    public void set(int key) { this.key = key; }

    @Override
    public JsonElement save() { return new JsonPrimitive(key); }

    @Override
    public void load(JsonElement json) {
        if (json.isJsonPrimitive() && json.getAsJsonPrimitive().isNumber()) key = json.getAsInt();
    }
}
