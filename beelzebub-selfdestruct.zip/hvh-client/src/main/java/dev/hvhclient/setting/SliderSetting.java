package dev.hvhclient.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

/** Tek noktalı slider (tam sayı). */
public class SliderSetting extends Setting {
    private final int min, max;
    private int value;
    private String maxLabel;

    public SliderSetting(String name, int min, int max, int def) {
        super(name);
        this.min = min;
        this.max = max;
        this.value = Math.max(min, Math.min(def, max));
    }

    /** Değer maksimuma ulaşınca GUI'de sayı yerine bu yazı görünür (ör. "Infinite"). */
    public SliderSetting maxLabel(String label) {
        this.maxLabel = label;
        return this;
    }

    public int getMin() { return min; }
    public int getMax() { return max; }
    public int get() { return value; }
    public void set(int v) { value = Math.max(min, Math.min(v, max)); }
    public boolean isMax() { return value >= max; }

    public String display() {
        return (isMax() && maxLabel != null) ? maxLabel : String.valueOf(value);
    }

    @Override
    public JsonElement save() { return new JsonPrimitive(value); }

    @Override
    public void load(JsonElement json) {
        if (json.isJsonPrimitive() && json.getAsJsonPrimitive().isNumber()) set(json.getAsInt());
    }
}
