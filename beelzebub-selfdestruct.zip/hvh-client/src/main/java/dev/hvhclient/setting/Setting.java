package dev.hvhclient.setting;

import com.google.gson.JsonElement;

public abstract class Setting {
    private final String name;

    protected Setting(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    /** Config dosyasına yazılacak değer. */
    public abstract JsonElement save();

    /** Config dosyasından değeri geri yükler. */
    public abstract void load(JsonElement json);
}
