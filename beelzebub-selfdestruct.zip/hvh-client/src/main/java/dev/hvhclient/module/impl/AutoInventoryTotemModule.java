package dev.hvhclient.module.impl;

import dev.hvhclient.module.Category;
import dev.hvhclient.module.Module;
import dev.hvhclient.setting.BoolSetting;
import dev.hvhclient.setting.SliderSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.PlayerScreenHandler;
import net.minecraft.screen.slot.SlotActionType;

/**
 * Envanter açıkken, can Health eşiğine ya da altına düşmüşse totemi offhand'e
 * (ve Hover açıksa belirlenen hotbar slotuna) koyar.
 * PlayerScreenHandler slotları: 9-35 ana envanter, 36-44 hotbar, 45 offhand.
 */
public class AutoInventoryTotemModule extends Module {
    private static final int INV_START = 9, HOTBAR_START = 36, HOTBAR_END = 44;
    private static final int OFFHAND_BUTTON = 40;

    private final BoolSetting hover = add(new BoolSetting("Hover", true));
    private final BoolSetting autoOpen = add(new BoolSetting("Auto Open", false));
    private final SliderSetting health = add(new SliderSetting("Health", 1, 20, 10));
    private final BoolSetting autoClose = add(new BoolSetting("Auto Close", false));
    private final SliderSetting totemSlot = add(new SliderSetting("Totem Slot", 1, 9, 9));

    /** Bu envanter oturumunda modül açtı veya totem taşıdı mı (Auto Close sadece o zaman kapatır). */
    private boolean session;
    private long lastAutoOpen;

    public AutoInventoryTotemModule() {
        super("AutoInventoryTotem", Category.MAIN);
    }

    @Override
    protected void onDisable() {
        session = false;
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null) return;

        // Envanter kapalı: istenirse can düşünce otomatik aç.
        if (!(mc.currentScreen instanceof InventoryScreen)) {
            session = false;
            if (mc.currentScreen == null && autoOpen.get() && p.isAlive()
                    && p.getHealth() <= health.get() && canFillSomething(p)
                    && System.currentTimeMillis() - lastAutoOpen > 250) {
                lastAutoOpen = System.currentTimeMillis();
                mc.setScreen(new InventoryScreen(p));
                session = true;
            }
            return;
        }

        PlayerScreenHandler h = p.playerScreenHandler;
        if (p.currentScreenHandler != h || !h.getCursorStack().isEmpty()) return;

        int slotIdx = totemSlot.get() - 1;
        boolean offhandHas = isTotem(p.getOffHandStack());
        boolean slotHas = isTotem(p.getInventory().getStack(slotIdx));

        // Health eşiği: can bu değerin üstündeyken envanter açık olsa bile totem taşınmaz.
        if (p.getHealth() <= health.get()) {
            // Tick başına tek hamle: önce offhand, sonra Totem Slot.
            if (!offhandHas) {
                int from = findTotem(h, slotIdx, true);
                if (from != -1) {
                    mc.interactionManager.clickSlot(h.syncId, from, OFFHAND_BUTTON, SlotActionType.SWAP, p);
                    session = true;
                    return;
                }
            } else if (hover.get() && !slotHas) {
                int from = findTotem(h, slotIdx, false);
                if (from != -1) {
                    mc.interactionManager.clickSlot(h.syncId, from, slotIdx, SlotActionType.SWAP, p);
                    session = true;
                    return;
                }
            }
        }

        // Yapılacak hamle kalmadı ve offhand'de totem var -> kapat.
        if (autoClose.get() && session && offhandHas) {
            p.closeHandledScreen();
            session = false;
        }
    }

    /** Auto Open için: doldurulabilecek (kaynağı olan) bir boşluk var mı. */
    private boolean canFillSomething(ClientPlayerEntity p) {
        PlayerScreenHandler h = p.playerScreenHandler;
        int slotIdx = totemSlot.get() - 1;
        if (!isTotem(p.getOffHandStack())) return findTotem(h, slotIdx, true) != -1;
        if (hover.get() && !isTotem(p.getInventory().getStack(slotIdx))) return findTotem(h, slotIdx, false) != -1;
        return false;
    }

    /**
     * Kaynak totem slotunu bulur (ekran slot id'si, yoksa -1). Önce ana envanter, sonra diğer hotbar slotları.
     * allowTotemSlot: offhand doldurulurken Totem Slot'taki totem de son çare olarak kullanılabilir.
     */
    private int findTotem(PlayerScreenHandler h, int slotIdx, boolean allowTotemSlot) {
        for (int i = INV_START; i < HOTBAR_START; i++) {
            if (isTotem(h.getSlot(i).getStack())) return i;
        }
        int targetId = HOTBAR_START + slotIdx;
        for (int i = HOTBAR_START; i <= HOTBAR_END; i++) {
            if (i == targetId) continue;
            if (isTotem(h.getSlot(i).getStack())) return i;
        }
        if (allowTotemSlot && isTotem(h.getSlot(targetId).getStack())) return targetId;
        return -1;
    }

    private static boolean isTotem(ItemStack stack) {
        return stack.isOf(Items.TOTEM_OF_UNDYING);
    }
}
