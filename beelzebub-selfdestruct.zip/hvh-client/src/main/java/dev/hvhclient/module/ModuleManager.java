package dev.hvhclient.module;

import dev.hvhclient.module.impl.AutoInventoryTotemModule;
import dev.hvhclient.module.impl.SelfDestructModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ModuleManager {
    private static final List<Module> MODULES = new ArrayList<>();
    private static boolean destroyed;

    public static void init() {
        register(new AutoInventoryTotemModule());
        register(new SelfDestructModule());
    }

    public static boolean isDestroyed() { return destroyed; }

    /** SelfDestruct: tüm modülleri kapatır, bundan sonra hiçbir şey çalışmaz. */
    public static void destroy() {
        destroyed = true;
        for (Module m : MODULES) m.setEnabled(false);
    }

    private static void register(Module module) {
        MODULES.add(module);
    }

    public static Module getByName(String name) {
        String n = name.replace(" ", "");
        for (Module m : MODULES) {
            if (m.getName().equalsIgnoreCase(n)) return m;
        }
        return null;
    }

    public static List<Module> getModules() {
        return Collections.unmodifiableList(MODULES);
    }

    public static List<Module> getByCategory(Category category) {
        List<Module> out = new ArrayList<>();
        for (Module m : MODULES) {
            if (m.getCategory() == category) out.add(m);
        }
        return out;
    }

    /** Bind atanmış modülleri tuşa basılınca aç/kapat (sadece oyun içinde, ekran açık değilken). */
    public static void handleBinds(MinecraftClient mc) {
        if (destroyed) return;
        long window = mc.getWindow().getHandle();
        for (Module m : MODULES) {
            int key = m.getKey();
            if (key < 0) {
                m.setKeyDown(false);
                continue;
            }
            boolean down = InputUtil.isKeyPressed(window, key);
            if (down && !m.isKeyDown() && mc.currentScreen == null) m.toggle();
            m.setKeyDown(down);
        }
    }

    public static void tick(MinecraftClient mc) {
        if (destroyed) return;
        for (Module m : MODULES) {
            if (m.isEnabled()) m.onTick(mc);
        }
    }
}
