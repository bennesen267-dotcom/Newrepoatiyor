package dev.hvhclient.module;

public enum Category {
    MAIN("Client");

    public final String label;

    Category(String label) {
        this.label = label;
    }
}
