package dev.hvhclient.module.impl;

import dev.hvhclient.ClientMain;
import dev.hvhclient.config.ConfigManager;
import dev.hvhclient.module.Category;
import dev.hvhclient.module.Module;
import dev.hvhclient.module.ModuleManager;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ConfirmScreen;
import net.minecraft.text.Text;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;

/**
 * Açılınca "emin misin?" sorar. Evet denirse client kendini devre dışı bırakır ve
 * kendi dosyalarını siler: config/beelzebub.json ve mod jar'ı.
 * Sadece Beelzebub'un kendi dosyalarına dokunur; oyunun loglarına ve diğer modlara dokunmaz.
 *
 * Not: Windows çalışan jar'ı kilitler. Silinemezse oyun kapanırken silen bir işlem başlatılır.
 */
public class SelfDestructModule extends Module {
    private static final Logger LOG = LoggerFactory.getLogger(ClientMain.NAME);

    public SelfDestructModule() {
        super("SelfDestruct", Category.MAIN);
    }

    @Override
    protected void onEnable() {
        // Modül hiçbir zaman "açık" kalmaz; her açılış sadece onay penceresini tetikler.
        MinecraftClient mc = MinecraftClient.getInstance();
        setEnabled(false);
        if (mc == null || mc.player == null || ModuleManager.isDestroyed()) return;

        mc.execute(() -> mc.setScreen(new ConfirmScreen(
                yes -> {
                    mc.setScreen(null);
                    if (yes) destruct();
                },
                Text.literal("Self Destruct"),
                Text.literal("Client devre dışı bırakılacak, config ve mod dosyası silinecek. Emin misin?"),
                Text.literal("Evet"),
                Text.literal("Hayır"))));
    }

    private static void destruct() {
        // 1) Her şeyi durdur ve config'in tekrar yazılmasını engelle.
        ModuleManager.destroy();

        // 2) Config dosyası.
        ConfigManager.deleteFile();

        // 3) Mod jar'ı.
        deleteOwnJar();
    }

    private static void deleteOwnJar() {
        ModContainer container = FabricLoader.getInstance().getModContainer("beelzebub").orElse(null);
        if (container == null) return;

        for (Path path : container.getOrigin().getPaths()) {
            // Geliştirme ortamında origin bir klasördür; sadece gerçek .jar dosyası silinir.
            if (!Files.isRegularFile(path) || !path.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".jar")) {
                continue;
            }
            try {
                Files.deleteIfExists(path);
            } catch (IOException e) {
                // Windows: jar kilitli. Oyun kapanınca silinsin.
                scheduleDeleteOnExit(path);
            }
        }
    }

    private static void scheduleDeleteOnExit(Path jar) {
        String os = System.getProperty("os.name", "").toLowerCase(Locale.ROOT);
        if (!os.contains("win")) {
            LOG.warn("Mod dosyası silinemedi: {}", jar);
            return;
        }
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            try {
                // JVM'in kapanıp jar'ı bırakması için kısa bekleme, sonra sil.
                new ProcessBuilder("cmd", "/c",
                        "ping -n 4 127.0.0.1 >nul & del /f /q \"" + jar.toAbsolutePath() + "\"")
                        .start();
            } catch (IOException ignored) {
                // yapacak bir şey yok
            }
        }));
    }
}
