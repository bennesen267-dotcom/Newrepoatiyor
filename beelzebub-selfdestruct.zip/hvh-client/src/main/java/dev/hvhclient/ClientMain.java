package dev.hvhclient;

import dev.hvhclient.config.ConfigManager;
import dev.hvhclient.gui.ClickGuiScreen;
import dev.hvhclient.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class ClientMain implements ClientModInitializer {
    public static final String NAME = "Beelzebub";

    private static KeyBinding openGui;

    @Override
    public void onInitializeClient() {
        ModuleManager.init();
        ConfigManager.load();

        openGui = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "ClickGUI", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_O, NAME));

        ClientLifecycleEvents.CLIENT_STOPPING.register(mc -> ConfigManager.save());

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (openGui.wasPressed()) {
                if (mc.currentScreen == null && !ModuleManager.isDestroyed()) mc.setScreen(new ClickGuiScreen());
            }
            if (mc.player != null && mc.world != null) {
                ModuleManager.handleBinds(mc);
                ModuleManager.tick(mc);
            }
        });
    }
}
